
// set variables
var clock = document.getElementById('clock');
var date = new Date();

// display time
clock.innerHTML = date.toTimeString();